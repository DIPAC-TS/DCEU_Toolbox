from setuptools import setup

setup(
    name="DCEU Toolbox",
    version="0.3.0",
    description="Workshop toolbox for DIPAC THERMAL SOLUTIONS",
    author="MEng. Efraín Alonso Puerto",
    author_email="efrainpuerto@gmail.com",
    url="https//efrainpuerto.com",
    packages=["DCEU_Toolbox"]
)